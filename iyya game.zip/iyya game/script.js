let player1Move = null;
let score1 = 0;
let score2 = 0;

function chooseMove1() {
  const move1 = document.getElementById("move1").value;
  if (move1) {
    player1Move = move1;
    document.getElementById("move1").style.visibility = "hidden";
    document.getElementById("move2").disabled = false;
    document.getElementById("playBtn").disabled = false;
  }
}

function playGame() {
  const move2 = document.getElementById("move2").value;
  const resultDiv = document.getElementById("result");
  const historyList = document.getElementById("historyList");

  if (!player1Move || !move2) {
    resultDiv.textContent = "Both players must choose a move!";
    resultDiv.classList.add("show");
    return;
  }

  const battleScene = document.getElementById("battleScene");
  const p1Icon = document.getElementById("p1Icon");
  const p2Icon = document.getElementById("p2Icon");

  p1Icon.textContent = getIcon(player1Move);
  p2Icon.textContent = getIcon(move2);

  battleScene.style.display = "flex";
  battleScene.classList.add("animate");

  resultDiv.classList.remove("show");
  resultDiv.textContent = "";
  document.body.classList.add("shake");
setTimeout(() => {
  document.body.classList.remove("shake");
}, 500);

  setTimeout(() => {
    battleScene.classList.remove("animate");
    battleScene.style.display = "none";

    let resultText = "";

    if (player1Move === move2) {
      resultText = "🤝 It's a tie!";
    } else if (isWinner(player1Move, move2)) {
      resultText = "🎉 Player 1 wins!";
      score1++;
    } else {
      resultText = "🎉 Player 2 wins!";
      score2++;
    }

    resultDiv.textContent = resultText;
    resultDiv.classList.add("show");

    document.getElementById("score1").textContent = score1;
    document.getElementById("score2").textContent = score2;

    const listItem = document.createElement("li");
    listItem.textContent = `Player 1: ${player1Move}, Player 2: ${move2} → ${resultText}`;
    historyList.appendChild(listItem);

    document.getElementById("move1").style.visibility = "visible";
    document.getElementById("move1").value = "";
    document.getElementById("move2").value = "";
    document.getElementById("move2").disabled = true;
    document.getElementById("playBtn").disabled = true;
    player1Move = null;
  }, 1500);
}

function restartGame() {
  score1 = 0;
  score2 = 0;
  player1Move = null;

  document.getElementById("score1").textContent = 0;
  document.getElementById("score2").textContent = 0;
  document.getElementById("result").textContent = "";
  document.getElementById("result").classList.remove("show");
  document.getElementById("move1").value = "";
  document.getElementById("move1").style.visibility = "visible";
  document.getElementById("move2").value = "";
  document.getElementById("move2").disabled = true;
  document.getElementById("playBtn").disabled = true;
  document.getElementById("historyList").innerHTML = "";
}

function isWinner(p1, p2) {
  return (
    (p1 === "Stone" && (p2 === "Scissors" || p2 === "Fire")) ||
    (p1 === "Scissors" && (p2 === "Paper" || p2 === "Air")) ||
    (p1 === "Paper" && (p2 === "Stone" || p2 === "Water")) ||
    (p1 === "Water" && (p2 === "Fire" || p2 === "Stone")) ||
    (p1 === "Fire" && (p2 === "Paper" || p2 === "Air")) ||
    (p1 === "Air" && (p2 === "Water" || p2 === "Scissors"))
  );
}
function getIcon(move) {
  switch (move) {
    case "Stone": return "🪨";
    case "Paper": return "📄";
    case "Scissors": return "✂️";
    case "Water": return "💧";
    case "Fire": return "🔥";
    case "Air": return "🌬️";
    default: return "❓";
  }
}
function showRules(type) {
  const rulesText = document.getElementById("rulesText");
  const modal = document.getElementById("rulesModal");

  if (type === "basic") {
    rulesText.innerHTML = `
      <h4>📘 Basic Rules</h4>
      <p>Each player selects one of six elements: Stone, Paper, Scissors, Water, Air, or Fire.</p>
      <p>After both selections are made, the winner is determined based on the element rules.</p>
    `;
  } else if (type === "win") {
    rulesText.innerHTML = `
      <h4>🏆 Win Conditions</h4>
      <ul>
        <li>Stone beats Scissors and Fire</li>
        <li>Scissors beats Paper and Air</li>
        <li>Paper beats Stone, Water, and Air</li>
        <li>Water beats Fire and Stone</li>
        <li>Fire beats Paper and Air</li>
        <li>Air beats Water and Scissors</li>
      </ul>
    `;
  } else if (type === "tips") {
    rulesText.innerHTML = `
      <h4>💡 Strategy Tips</h4>
      <ul>
        <li>Try to remember your opponent’s patterns.</li>
        <li>Don't repeat the same move often!</li>
        <li>Use Air or Water to surprise — they are less expected!</li>
      </ul>
    `;
  }

  modal.classList.remove("hidden");
}

function closeRules() {
  document.getElementById("rulesModal").classList.add("hidden");
}
